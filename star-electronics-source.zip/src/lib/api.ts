import axios from 'axios';

// In the AppDeploy runtime, requests go through the platform's managed
// `@appdeploy/client`. For local development (npm run dev) and any other
// standalone hosting, this is a plain axios client instead - vite.config.ts
// proxies /api to the deployed backend so no CORS setup is needed locally.
const api = axios.create({ baseURL: '' });

function getToken(): string {
  return localStorage.getItem('star_token') || '';
}

function withToken(params: Record<string, unknown> = {}): Record<string, unknown> {
  return { ...params, token: getToken() };
}

function toQueryString(params: Record<string, unknown>): string {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') usp.set(k, String(v));
  });
  return usp.toString();
}

export const apiClient = {
  get: (url: string, params: Record<string, unknown> = {}) => {
    const qs = toQueryString(withToken(params));
    const sep = url.includes('?') ? '&' : '?';
    return api.get(`${url}${sep}${qs}`);
  },
  post: (url: string, body: Record<string, unknown> = {}) => api.post(url, withToken(body)),
  put: (url: string, body: Record<string, unknown> = {}) => api.put(url, withToken(body)),
  del: (url: string, params: Record<string, unknown> = {}) => {
    const qs = toQueryString(withToken(params));
    const sep = url.includes('?') ? '&' : '?';
    return api.delete(`${url}${sep}${qs}`);
  },
};

export function setToken(t: string): void {
  localStorage.setItem('star_token', t);
}
export function clearToken(): void {
  localStorage.removeItem('star_token');
}
export function getStoredToken(): string {
  return getToken();
}
