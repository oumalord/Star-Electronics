import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Star Electronics dev server.
// The backend lives on Anthropic's AppDeploy platform (it uses the
// @appdeploy/sdk for its database, secrets, and router - that only runs on
// their infrastructure). To develop the frontend locally against the real,
// already-deployed backend and data, every /api request is proxied there.
// Change BACKEND_URL if you migrate the backend elsewhere.
const BACKEND_URL = process.env.VITE_BACKEND_URL || 'https://star-electronics-0waw7r.v2.appdeploy.ai';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: BACKEND_URL,
        changeOrigin: true,
        secure: true,
      },
    },
  },
});
