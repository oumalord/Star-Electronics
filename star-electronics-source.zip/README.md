# Star Electronics — Shop Management, Inventory, POS & M-Pesa Platform

Live app: https://star-electronics-0waw7r.v2.appdeploy.ai/
Owner login: **Admin** / **2114**

## Run it locally

```bash
npm install
npm run dev
```

Open http://localhost:5173. This runs the real frontend against the **already-deployed
live backend and database** — vite.config.ts proxies `/api/*` requests to
`https://star-electronics-0waw7r.v2.appdeploy.ai`, so there's no CORS setup needed and
no separate backend to run. Data you create locally is the same live data (same
database) as the hosted app.

To point at a different backend later, set `VITE_BACKEND_URL`:
```bash
VITE_BACKEND_URL=https://your-backend.example.com npm run dev
```

`npm run build` produces a static `dist/` you can host anywhere (Vercel, Netlify, S3,
etc.) — just make sure whatever serves it also proxies/rewrites `/api/*` to a real
backend, since the built app still calls relative `/api/...` paths.

## Important: the backend is platform-specific

`backend/` is **not** a standalone Node server you can `npm run dev` locally as-is. It's
written for Anthropic's AppDeploy runtime and imports `@appdeploy/sdk`, which provides:
- a managed key-value database (`db.get/list/add/update/delete`)
- a request router (`router`, `json`, `error`)
- a secrets store (`secrets.readSecret`, used for M-Pesa Daraja credentials)

That package isn't published to npm and only runs inside AppDeploy's infrastructure —
it's included here so you have the full, real source (not a mock), and so you (or
another engineer) can port the route logic to a different backend (Express, Fastify,
a serverless framework, etc.) if you want to self-host the whole stack. The actual
business logic (auth, POS/stock rules, M-Pesa flow, permissions) is all in
`backend/index.ts` and its `backend/lib/*.ts` helpers, and is plain TypeScript aside
from those three SDK calls — porting it mainly means swapping the SDK calls for your
own database/router/secrets layer.

## Structure
- `src/` — React + TypeScript + Tailwind frontend (Vite)
  - `src/App.tsx` — routing & auth gating
  - `src/pages/` — one file per module (POS, Products, Sales, Repairs, Reports, etc.)
  - `src/components/` — shared UI (Layout/sidebar, Modal, Button, StatCard, etc.)
  - `src/lib/` — API client (axios), auth/toast context, formatting helpers
- `backend/` — Node/TypeScript serverless API (see note above)
  - `backend/index.ts` — all REST routes (auth, products, POS/sales, M-Pesa, repairs, reports, etc.)
  - `backend/lib/helpers.ts` — auth/session/permission/settings helpers
  - `backend/lib/mpesa.ts` — M-Pesa Daraja STK Push service (sandbox-simulated until live secrets are added)
  - `backend/lib/seed.ts` — owner-account bootstrap + one-time demo-data purge
  - `backend/lib/types.ts` — shared backend types
- `tests/tests.txt` — QA test scenarios

## Going live with M-Pesa
Add these as secrets in the AppDeploy dashboard (no code changes needed):
`MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_PASSKEY`, `MPESA_SHORTCODE`, `MPESA_CALLBACK_URL`

## Roles
owner, manager, sales, inventory, technician, accountant — permissions enforced
server-side in `backend/index.ts` (`authGuard` + `can()`), not just hidden in the UI.
